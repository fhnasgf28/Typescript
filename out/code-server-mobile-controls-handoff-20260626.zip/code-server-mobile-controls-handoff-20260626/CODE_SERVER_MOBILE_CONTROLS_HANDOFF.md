# Handoff Code-Server Mobile Controls

Dokumen ini menjelaskan cara memindahkan fitur Touch Mouse, Laptop Keys, edge scroll, dan default font JetBrains Mono ke server code-server lain. Paket ini menyertakan backup file aktif dari server sumber sehingga instalasi bisa direplikasi tanpa mengambil ulang dari server lama.

## Isi Paket

- backup/apollo-touch-mouse.js: layer Touch Mouse, virtual pointer panah, drag lock, right click, scroll mode, edge scroll, dan state warna pointer biru/merah.
- backup/apollo-touch-keyboard.js: panel Laptop Keys, tombol shortcut, native keyboard, copy smart terminal/editor, panel move/resize/reset, dan edge scroll.
- backup/workbench.html: contoh file workbench yang sudah memuat script injection dan cache-buster aktif.
- backup/workbench.css: CSS workbench yang sudah memuat font-face JetBrains Mono lokal.
- backup/JetBrainsMono-Regular.woff2 dan backup/JetBrainsMono-Italic.woff2: font lokal supaya tampilan konsisten lintas device.
- backup/settings.json: global user settings code-server untuk memakai JetBrains Mono pada editor, terminal, debug console, dan markdown preview.
- manifest.json dan checksums.sha256: metadata dan checksum file backup.

## Alur Instalasi Di Server Baru

1. Cari direktori workbench code-server.

    Contoh lokasi umum:

        /home/adminftp/.local/lib/code-server/lib/vscode/out/vs/code/browser/workbench

    Jika lokasi berbeda, cari file workbench.html:

        find /home/adminftp/.local/lib/code-server -path "*/workbench/workbench.html" -print

2. Buat backup file lama sebelum menimpa.

        cd /path/ke/workbench
        cp -a workbench.html workbench.html.apollo_bak_YYYYMMDDHHMMSS
        cp -a workbench.css workbench.css.apollo_bak_YYYYMMDDHHMMSS
        test -f apollo-touch-mouse.js && cp -a apollo-touch-mouse.js apollo-touch-mouse.js.apollo_bak_YYYYMMDDHHMMSS
        test -f apollo-touch-keyboard.js && cp -a apollo-touch-keyboard.js apollo-touch-keyboard.js.apollo_bak_YYYYMMDDHHMMSS

3. Copy file dari folder backup paket ini ke direktori workbench server baru.

        cp backup/apollo-touch-mouse.js /path/ke/workbench/
        cp backup/apollo-touch-keyboard.js /path/ke/workbench/
        cp backup/JetBrainsMono-Regular.woff2 /path/ke/workbench/
        cp backup/JetBrainsMono-Italic.woff2 /path/ke/workbench/

4. Pasang script Touch Mouse dan Laptop Keys di workbench.html sebelum tag penutup head jika belum ada.

        <script defer src="{{WORKBENCH_WEB_BASE_URL}}/out/vs/code/browser/workbench/apollo-touch-keyboard.js?v=apollo-keyboard-20260626-edgescroll"></script>
        <script defer src="{{WORKBENCH_WEB_BASE_URL}}/out/vs/code/browser/workbench/apollo-touch-mouse.js?v=apollo-touch-20260626-pointer-blue-red"></script>

5. Pasang font JetBrains Mono global.

    Copy isi blok Apollo JetBrains Mono dari backup/workbench.css ke awal workbench.css server baru, atau gunakan backup/workbench.css jika versi code-server sama. Pastikan file font woff2 sudah ada di direktori workbench.

6. Merge global settings code-server.

    File tujuan biasanya:

        /home/adminftp/.local/share/code-server/User/settings.json

    Minimal key yang perlu ada:

        "editor.fontFamily": "JetBrains Mono, Fira Code, Consolas, monospace"
        "editor.fontLigatures": true
        "editor.fontVariations": false
        "terminal.integrated.fontFamily": "JetBrains Mono, Fira Code, Consolas, monospace"
        "debug.console.fontFamily": "JetBrains Mono, Fira Code, Consolas, monospace"
        "markdown.preview.fontFamily": "JetBrains Mono, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif"

7. Restart atau reload code-server.

    Jika aman untuk user aktif, restart service code-server. Jika tidak, cukup hard refresh browser. Setelah edit script, cache-buster pada query string perlu berubah agar browser mengambil versi baru.

## Cara Pakai Touch Mouse

- Tekan tombol floating Mouse untuk menampilkan panel.
- Geser tombol floating atau panel sesuai posisi jari yang nyaman.
- Gerakkan virtual pointer dengan area touch, lalu tap untuk klik kiri.
- Tahan sebentar pada target untuk drag, atau gunakan tombol Drag Lock untuk drag manual.
- Gunakan tombol Right untuk klik kanan.
- Aktifkan Scroll untuk mode scroll, atau pakai strip scroll vertikal di sisi kanan/pojok layar.
- Pointer normal berwarna biru dan berubah merah saat ditekan, drag, atau state aktif.

## Cara Pakai Laptop Keys

- Tekan tombol floating Keys untuk membuka panel keyboard virtual.
- Gunakan tombol shortcut seperti arrow, escape, tab, enter, modifier, copy, paste, dan tombol lain sesuai panel.
- Tombol Copy otomatis memakai Ctrl+Shift+C saat fokus terminal dan Ctrl+C saat fokus editor.
- Tombol ABC memunculkan keyboard native device.
- Panel bisa dipindah, di-resize, di-hide, dan di-reset.
- Strip scroll vertikal di sisi kanan/pojok memudahkan scroll pakai jari tanpa mengganggu panel.

## Verifikasi

Jalankan dari direktori workbench server baru:

        node --check apollo-touch-mouse.js
        node --check apollo-touch-keyboard.js
        grep -F "apollo-touch-20260626-pointer-blue-red" workbench.html
        grep -F "apollo-keyboard-20260626-edgescroll" workbench.html
        grep -F "Apollo JetBrains Mono local webfont" workbench.css

Buka code-server dari browser mobile, hard refresh, lalu pastikan tombol Mouse dan Keys muncul. Buka editor dan terminal untuk memastikan font JetBrains Mono aktif.

## Rollback

1. Restore file backup dengan suffix apollo_bak dari server tujuan.
2. Hapus script apollo-touch-mouse.js dan apollo-touch-keyboard.js dari workbench.html jika ingin mematikan fitur penuh.
3. Restore settings.json lama jika font ingin dikembalikan.
4. Restart code-server atau hard refresh browser.

## Catatan Operasional

- Jangan memasukkan token, credential, atau isi env rahasia ke paket handoff.
- Jika code-server di server baru berbeda versi jauh, lebih aman merge manual blok script dan font daripada menimpa workbench.html/workbench.css secara penuh.
- Script punya guard global di browser, jadi setelah update file aktif lakukan hard refresh atau ubah cache-buster.
- Untuk konsistensi lintas device, kombinasi yang dipakai adalah font woff2 lokal di workbench.css dan global User/settings.json.
