(() => {
  "use strict";

  if (window.__apolloTouchMouseLoaded) {
    return;
  }
  window.__apolloTouchMouseLoaded = true;

  const STORE_KEY = "apollo.touchMouse.enabled";
  const LAYOUT_KEY = "apollo.touchMouse.panelLayout";
  const TOGGLE_LAYOUT_KEY = "apollo.touchMouse.toggleLayout";
  const VERSION = "20260626.4";

  function onReady(fn) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", fn, { once: true });
    } else {
      fn();
    }
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function hasCoarsePointer() {
    return window.matchMedia && window.matchMedia("(pointer: coarse)").matches;
  }

  function injectStyle() {
    if (document.getElementById("apollo-touch-mouse-style")) {
      return;
    }

    const style = document.createElement("style");
    style.id = "apollo-touch-mouse-style";
    style.textContent = `
      #apollo-touch-mouse-root {
        position: fixed;
        inset: 0;
        z-index: 2147483646;
        pointer-events: none;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      }

      #apollo-touch-mouse-root .atm-toggle {
        position: fixed;
        right: max(12px, env(safe-area-inset-right));
        bottom: max(12px, env(safe-area-inset-bottom));
        min-width: 64px;
        height: 42px;
        border: 1px solid rgba(255, 255, 255, 0.24);
        border-radius: 999px;
        background: rgba(31, 41, 55, 0.88);
        color: #ffffff;
        box-shadow: 0 10px 28px rgba(0, 0, 0, 0.38);
        backdrop-filter: blur(14px);
        pointer-events: auto;
        touch-action: none;
        cursor: grab;
        font-size: 13px;
        font-weight: 650;
      }

      #apollo-touch-mouse-root.atm-enabled .atm-toggle {
        background: rgba(37, 99, 235, 0.92);
      }

      #apollo-touch-mouse-root .atm-cursor {
        position: fixed;
        width: 20px;
        height: 26px;
        margin-left: -1px;
        margin-top: -1px;
        background: transparent;
        opacity: 0.78;
        filter: drop-shadow(0 3px 6px rgba(0, 0, 0, 0.32));
        transform: translate3d(-100px, -100px, 0);
        pointer-events: none;
        display: none;
      }

      #apollo-touch-mouse-root .atm-cursor::before,
      #apollo-touch-mouse-root .atm-cursor::after {
        content: "";
        position: absolute;
        left: 0;
        top: 0;
        clip-path: polygon(0 0, 0 20px, 5px 15px, 9px 25px, 14px 23px, 10px 14px, 19px 14px);
      }

      #apollo-touch-mouse-root .atm-cursor::before {
        width: 20px;
        height: 26px;
        background: rgba(30, 64, 175, 0.68);
      }

      #apollo-touch-mouse-root .atm-cursor::after {
        left: 1.5px;
        top: 1.5px;
        width: 17px;
        height: 23px;
        background: rgba(37, 99, 235, 0.82);
      }

      #apollo-touch-mouse-root.atm-pointer-active .atm-cursor {
        opacity: 0.94;
        filter: drop-shadow(0 0 8px rgba(239, 68, 68, 0.86)) drop-shadow(0 3px 7px rgba(0, 0, 0, 0.38));
      }

      #apollo-touch-mouse-root.atm-pointer-active .atm-cursor::before {
        background: rgba(127, 29, 29, 0.82);
      }

      #apollo-touch-mouse-root.atm-pointer-active .atm-cursor::after {
        background: rgba(239, 68, 68, 0.9);
      }

      #apollo-touch-mouse-root.atm-enabled .atm-cursor {
        display: block;
      }

      #apollo-touch-mouse-root .atm-panel {
        position: fixed;
        left: 50%;
        bottom: max(16px, env(safe-area-inset-bottom));
        transform: translateX(-50%);
        width: min(94vw, 620px);
        height: min(34vh, 250px);
        min-height: 164px;
        border: 1px solid rgba(255, 255, 255, 0.20);
        border-radius: 18px;
        background: rgba(17, 24, 39, 0.86);
        color: #ffffff;
        box-shadow: 0 22px 56px rgba(0, 0, 0, 0.48);
        backdrop-filter: blur(16px);
        pointer-events: auto;
        touch-action: none;
        display: none;
        overflow: auto;
        min-width: 280px;
        min-height: 150px;
        max-width: calc(100vw - 12px);
        max-height: calc(100vh - 12px);
        user-select: none;
        -webkit-user-select: none;
      }

      #apollo-touch-mouse-root.atm-enabled .atm-panel {
        display: grid;
        grid-template-rows: 44px 1fr 52px;
      }

      #apollo-touch-mouse-root .atm-header,
      #apollo-touch-mouse-root .atm-actions {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px 10px;
      }

      #apollo-touch-mouse-root .atm-header {
        border-bottom: 1px solid rgba(255, 255, 255, 0.10);
        cursor: move;
        touch-action: none;
      }

      #apollo-touch-mouse-root .atm-resize {
        position: absolute;
        right: 5px;
        bottom: 5px;
        width: 22px;
        height: 22px;
        border-radius: 7px;
        background: linear-gradient(135deg, transparent 0 45%, rgba(255,255,255,0.35) 46% 54%, transparent 55%), linear-gradient(135deg, transparent 0 63%, rgba(255,255,255,0.28) 64% 72%, transparent 73%);
        cursor: nwse-resize;
        touch-action: none;
        pointer-events: auto;
        opacity: 0.85;
      }

      #apollo-touch-mouse-root .atm-title {
        flex: 1;
        font-size: 13px;
        font-weight: 650;
      }

      #apollo-touch-mouse-root .atm-status {
        font-size: 11px;
        color: rgba(255, 255, 255, 0.68);
      }

      #apollo-touch-mouse-root .atm-pad {
        position: relative;
        touch-action: none;
        user-select: none;
        background: repeating-linear-gradient(135deg, rgba(255,255,255,0.045), rgba(255,255,255,0.045) 1px, transparent 1px, transparent 12px);
      }

      #apollo-touch-mouse-root .atm-pad::after {
        content: "1 jari cursor/tap, tahan drag, 2 jari drag";
        position: absolute;
        inset: 0;
        display: grid;
        place-items: center;
        color: rgba(255, 255, 255, 0.42);
        font-size: 13px;
        pointer-events: none;
      }

      #apollo-touch-mouse-root .atm-edge-scroll {
        position: absolute;
        top: 50px;
        right: 5px;
        bottom: 58px;
        width: 28px;
        border: 1px solid rgba(147, 197, 253, 0.46);
        border-radius: 999px;
        background: rgba(37, 99, 235, 0.44);
        color: rgba(255, 255, 255, 0.88);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        font-weight: 750;
        pointer-events: auto;
        touch-action: none;
        user-select: none;
        -webkit-user-select: none;
        z-index: 3;
      }

      #apollo-touch-mouse-root .atm-edge-scroll span {
        transform: rotate(90deg);
        white-space: nowrap;
      }

      #apollo-touch-mouse-root .atm-edge-scroll:active {
        background: rgba(37, 99, 235, 0.78);
        border-color: rgba(191, 219, 254, 0.84);
      }

      #apollo-touch-mouse-root .atm-actions {
        border-top: 1px solid rgba(255, 255, 255, 0.10);
      }

      #apollo-touch-mouse-root .atm-btn {
        height: 34px;
        min-width: 42px;
        padding: 0 12px;
        border: 1px solid rgba(255, 255, 255, 0.16);
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.11);
        color: #ffffff;
        font-size: 12px;
        font-weight: 650;
        pointer-events: auto;
        touch-action: manipulation;
      }

      #apollo-touch-mouse-root .atm-btn:active,
      #apollo-touch-mouse-root .atm-btn.atm-active {
        background: rgba(37, 99, 235, 0.92);
        border-color: rgba(147, 197, 253, 0.82);
      }

      #apollo-touch-mouse-root .atm-move {
        min-width: 58px;
        background: rgba(245, 158, 11, 0.96);
        border-color: rgba(253, 230, 138, 0.92);
        color: #111827;
      }

      #apollo-touch-mouse-root .atm-spacer {
        flex: 1;
      }

      @media (max-width: 700px) {
        #apollo-touch-mouse-root .atm-status { display: none; }
        #apollo-touch-mouse-root .atm-panel {
          width: calc(100vw - 16px);
          height: min(38vh, 240px);
          bottom: max(8px, env(safe-area-inset-bottom));
          border-radius: 14px;
        }
        #apollo-touch-mouse-root .atm-toggle {
          right: max(8px, env(safe-area-inset-right));
          bottom: max(8px, env(safe-area-inset-bottom));
        }
      }
    `;
    document.head.appendChild(style);
  }

  function createRoot() {
    const root = document.createElement("div");
    root.id = "apollo-touch-mouse-root";
    root.dataset.version = VERSION;
    root.innerHTML = `
      <button class="atm-toggle" type="button" aria-label="Toggle touch mouse mode">Mouse</button>
      <div class="atm-cursor" aria-hidden="true"></div>
      <section class="atm-panel" aria-label="Touch mouse pad">
        <div class="atm-header">
          <div class="atm-title">Touch Mouse</div>
          <div class="atm-status">tap=klik, tahan+geser=drag</div>
          <button class="atm-btn atm-move" type="button">Move</button>
          <button class="atm-btn atm-reset" type="button">Reset</button>
          <button class="atm-btn atm-close" type="button">Hide</button>
        </div>
        <div class="atm-pad" role="application" aria-label="Virtual trackpad"></div>
        <div class="atm-edge-scroll" role="slider" aria-label="Edge scroll"><span>Scroll</span></div>
        <div class="atm-actions">
          <button class="atm-btn atm-left" type="button">Left</button>
          <button class="atm-btn atm-right" type="button">Right</button>
          <button class="atm-btn atm-drag" type="button">Drag</button>
          <button class="atm-btn atm-scroll" type="button">Scroll</button>
          <span class="atm-spacer"></span>
          <button class="atm-btn atm-center" type="button">Center</button>
        </div>
        <div class="atm-resize" aria-label="Resize touch mouse panel"></div>
      </section>
    `;
    document.body.appendChild(root);
    return root;
  }

  onReady(() => {
    injectStyle();

    const existing = document.getElementById("apollo-touch-mouse-root");
    if (existing) {
      existing.remove();
    }

    const root = createRoot();
    const toggle = root.querySelector(".atm-toggle");
    const panel = root.querySelector(".atm-panel");
    const header = root.querySelector(".atm-header");
    const resizeHandle = root.querySelector(".atm-resize");
    const moveHandle = root.querySelector(".atm-move");
    const pad = root.querySelector(".atm-pad");
    const edgeScroll = root.querySelector(".atm-edge-scroll");
    const cursor = root.querySelector(".atm-cursor");
    const dragBtn = root.querySelector(".atm-drag");
    const scrollBtn = root.querySelector(".atm-scroll");

    let toggleSuppressClick = false;

    const state = {
      enabled: localStorage.getItem(STORE_KEY) === "1" || (hasCoarsePointer() && localStorage.getItem(STORE_KEY) !== "0"),
      x: Math.round(window.innerWidth * 0.52),
      y: Math.round(window.innerHeight * 0.45),
      lastX: 0,
      lastY: 0,
      startX: 0,
      startY: 0,
      down: false,
      moved: false,
      drag: false,
      holdDrag: false,
      twoFingerDrag: false,
      twoFingerLastX: 0,
      twoFingerLastY: 0,
      scroll: false,
      longPressTimer: 0,
      lastTarget: null,
    };



    function defaultPanelLayout() {
      const width = Math.round(Math.min(window.innerWidth * 0.94, 620));
      const height = Math.round(Math.max(164, Math.min(window.innerHeight * 0.34, 250)));
      return {
        left: Math.round((window.innerWidth - width) / 2),
        top: Math.round(window.innerHeight - height - 16),
        width,
        height,
      };
    }

    function clampPanelLayout(layout) {
      const margin = 6;
      const minWidth = Math.min(280, Math.max(160, window.innerWidth - margin * 2));
      const minHeight = Math.min(150, Math.max(120, window.innerHeight - margin * 2));
      const maxWidth = Math.max(minWidth, window.innerWidth - margin * 2);
      const maxHeight = Math.max(minHeight, window.innerHeight - margin * 2);
      const width = clamp(Number(layout.width) || minWidth, minWidth, maxWidth);
      const height = clamp(Number(layout.height) || minHeight, minHeight, maxHeight);
      return {
        left: clamp(Number(layout.left) || margin, margin, window.innerWidth - width - margin),
        top: clamp(Number(layout.top) || margin, margin, window.innerHeight - height - margin),
        width,
        height,
      };
    }

    function applyPanelLayout(layout) {
      const safe = clampPanelLayout(layout);
      panel.style.left = `${safe.left}px`;
      panel.style.top = `${safe.top}px`;
      panel.style.width = `${safe.width}px`;
      panel.style.height = `${safe.height}px`;
      panel.style.right = "auto";
      panel.style.bottom = "auto";
      panel.style.transform = "none";
      return safe;
    }

    function readPanelLayout() {
      return {
        left: parseFloat(panel.style.left) || panel.getBoundingClientRect().left,
        top: parseFloat(panel.style.top) || panel.getBoundingClientRect().top,
        width: parseFloat(panel.style.width) || panel.getBoundingClientRect().width,
        height: parseFloat(panel.style.height) || panel.getBoundingClientRect().height,
      };
    }

    function savePanelLayout() {
      localStorage.setItem(LAYOUT_KEY, JSON.stringify(clampPanelLayout(readPanelLayout())));
    }

    function loadPanelLayout() {
      let layout = null;
      try { layout = JSON.parse(localStorage.getItem(LAYOUT_KEY) || "null"); } catch (_) {}
      applyPanelLayout(layout || defaultPanelLayout());
    }

    function installPanelMoveResize() {
      let mode = null;
      let startX = 0;
      let startY = 0;
      let startLayout = null;

      function begin(event, nextMode) {
        event.preventDefault();
        event.stopPropagation();
        mode = nextMode;
        try { event.currentTarget.setPointerCapture(event.pointerId); } catch (_) {}
        startX = event.clientX;
        startY = event.clientY;
        startLayout = readPanelLayout();
      }

      function move(event) {
        if (!mode || !startLayout) {
          return;
        }
        event.preventDefault();
        const dx = event.clientX - startX;
        const dy = event.clientY - startY;
        if (mode === "move") {
          applyPanelLayout({ ...startLayout, left: startLayout.left + dx, top: startLayout.top + dy });
        } else if (mode === "resize") {
          applyPanelLayout({ ...startLayout, width: startLayout.width + dx, height: startLayout.height + dy });
        }
      }

      function end() {
        if (!mode) {
          return;
        }
        savePanelLayout();
        mode = null;
        startLayout = null;
      }

      header.addEventListener("pointerdown", (event) => {
        if (event.target.closest("button")) {
          return;
        }
        begin(event, "move");
      });
      moveHandle.addEventListener("pointerdown", (event) => begin(event, "move"));
      resizeHandle.addEventListener("pointerdown", (event) => begin(event, "resize"));
      window.addEventListener("pointermove", move);
      window.addEventListener("pointerup", end);
      window.addEventListener("pointercancel", end);
      window.addEventListener("resize", () => {
        applyPanelLayout(readPanelLayout());
        savePanelLayout();
      });
    }

    loadPanelLayout();
    installPanelMoveResize();



    function defaultToggleLayout() {
      const rectWidth = 76;
      const rectHeight = 42;
      const margin = 12;
      return {
        left: Math.round(window.innerWidth - rectWidth - margin),
        top: Math.round(window.innerHeight - rectHeight - margin),
        width: rectWidth,
        height: rectHeight,
      };
    }

    function clampToggleLayout(layout) {
      const margin = 6;
      const rect = toggle.getBoundingClientRect();
      const width = Number(layout.width) || rect.width || 76;
      const height = Number(layout.height) || rect.height || 42;
      return {
        left: clamp(Number(layout.left) || margin, margin, window.innerWidth - width - margin),
        top: clamp(Number(layout.top) || margin, margin, window.innerHeight - height - margin),
        width,
        height,
      };
    }

    function applyToggleLayout(layout) {
      const safe = clampToggleLayout(layout);
      toggle.style.left = `${safe.left}px`;
      toggle.style.top = `${safe.top}px`;
      toggle.style.right = "auto";
      toggle.style.bottom = "auto";
      return safe;
    }

    function readToggleLayout() {
      const rect = toggle.getBoundingClientRect();
      return {
        left: parseFloat(toggle.style.left) || rect.left,
        top: parseFloat(toggle.style.top) || rect.top,
        width: rect.width,
        height: rect.height,
      };
    }

    function saveToggleLayout() {
      localStorage.setItem(TOGGLE_LAYOUT_KEY, JSON.stringify(clampToggleLayout(readToggleLayout())));
    }

    function loadToggleLayout() {
      let layout = null;
      try { layout = JSON.parse(localStorage.getItem(TOGGLE_LAYOUT_KEY) || "null"); } catch (_) {}
      applyToggleLayout(layout || defaultToggleLayout());
    }

    function installToggleMove() {
      let moving = false;
      let moved = false;
      let startX = 0;
      let startY = 0;
      let startLayout = null;

      toggle.addEventListener("pointerdown", (event) => {
        if (event.button && event.button !== 0) {
          return;
        }
        moving = true;
        moved = false;
        startX = event.clientX;
        startY = event.clientY;
        startLayout = readToggleLayout();
        try { toggle.setPointerCapture(event.pointerId); } catch (_) {}
      });

      toggle.addEventListener("pointermove", (event) => {
        if (!moving || !startLayout) {
          return;
        }
        const dx = event.clientX - startX;
        const dy = event.clientY - startY;
        if (Math.hypot(dx, dy) > 5) {
          moved = true;
          toggleSuppressClick = true;
        }
        if (moved) {
          event.preventDefault();
          applyToggleLayout({ ...startLayout, left: startLayout.left + dx, top: startLayout.top + dy });
        }
      });

      function endMove(event) {
        if (!moving) {
          return;
        }
        if (moved) {
          event.preventDefault();
          saveToggleLayout();
          window.setTimeout(() => { toggleSuppressClick = false; }, 80);
        }
        moving = false;
        moved = false;
        startLayout = null;
      }

      toggle.addEventListener("pointerup", endMove);
      toggle.addEventListener("pointercancel", endMove);
      window.addEventListener("resize", () => {
        applyToggleLayout(readToggleLayout());
        saveToggleLayout();
      });
    }

    loadToggleLayout();
    installToggleMove();

    function syncUi() {
      root.classList.toggle("atm-enabled", state.enabled);
      root.classList.toggle("atm-pointer-active", state.down || state.drag || state.holdDrag || state.twoFingerDrag);
      dragBtn.classList.toggle("atm-active", state.drag || state.twoFingerDrag);
      scrollBtn.classList.toggle("atm-active", state.scroll);
      toggle.textContent = state.enabled ? "Mouse On" : "Mouse";
      cursor.style.transform = `translate3d(${state.x}px, ${state.y}px, 0)`;
      localStorage.setItem(STORE_KEY, state.enabled ? "1" : "0");
    }

    function targetAtCursor() {
      const oldVisibility = root.style.visibility;
      root.style.visibility = "hidden";
      const target = document.elementFromPoint(state.x, state.y) || document.body;
      root.style.visibility = oldVisibility;
      return target;
    }

    function focusTarget(target) {
      const focusable = target && target.closest && target.closest("button, input, textarea, select, a, [tabindex], [contenteditable=true], .monaco-editor");
      if (focusable && typeof focusable.focus === "function") {
        try {
          focusable.focus({ preventScroll: true });
        } catch (_) {
          try { focusable.focus(); } catch (_) {}
        }
      }
    }

    function dispatchPointer(type, target, button, buttons) {
      if (!window.PointerEvent) {
        return;
      }
      const pointerType = type.replace("mouse", "pointer");
      target.dispatchEvent(new PointerEvent(pointerType, {
        bubbles: true,
        cancelable: true,
        composed: true,
        pointerId: 9042,
        pointerType: "mouse",
        isPrimary: true,
        clientX: state.x,
        clientY: state.y,
        screenX: window.screenX + state.x,
        screenY: window.screenY + state.y,
        button,
        buttons,
      }));
    }

    function dispatchMouse(type, button = 0, buttons = 0) {
      const target = targetAtCursor();
      state.lastTarget = target;
      focusTarget(target);
      if (type === "mousedown" || type === "mouseup" || type === "mousemove") {
        dispatchPointer(type, target, button, buttons);
      }
      target.dispatchEvent(new MouseEvent(type, {
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window,
        clientX: state.x,
        clientY: state.y,
        screenX: window.screenX + state.x,
        screenY: window.screenY + state.y,
        button,
        buttons,
      }));
    }

    function leftClick() {
      dispatchMouse("mousemove", 0, 0);
      dispatchMouse("mousedown", 0, 1);
      dispatchMouse("mouseup", 0, 0);
      dispatchMouse("click", 0, 0);
    }

    function rightClick() {
      const target = targetAtCursor();
      target.dispatchEvent(new MouseEvent("contextmenu", {
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window,
        clientX: state.x,
        clientY: state.y,
        screenX: window.screenX + state.x,
        screenY: window.screenY + state.y,
        button: 2,
        buttons: 2,
      }));
    }

    function dispatchWheel(deltaY, deltaX = 0) {
      const target = targetAtCursor();
      target.dispatchEvent(new WheelEvent("wheel", {
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window,
        clientX: state.x,
        clientY: state.y,
        deltaX,
        deltaY,
        deltaMode: WheelEvent.DOM_DELTA_PIXEL,
      }));
    }

    function installEdgeScroll() {
      let scrolling = false;
      let lastX = 0;
      let lastY = 0;

      function begin(event) {
        if (!state.enabled || (event.button && event.button !== 0)) {
          return;
        }
        event.preventDefault();
        event.stopPropagation();
        scrolling = true;
        lastX = event.clientX;
        lastY = event.clientY;
        clearLongPress();
        try { edgeScroll.setPointerCapture(event.pointerId); } catch (_) {}
      }

      function move(event) {
        if (!scrolling) {
          return;
        }
        event.preventDefault();
        event.stopPropagation();
        const dx = event.clientX - lastX;
        const dy = event.clientY - lastY;
        lastX = event.clientX;
        lastY = event.clientY;
        dispatchWheel(-dy * 4.4, -dx * 1.5);
      }

      function end(event) {
        if (!scrolling) {
          return;
        }
        event.preventDefault();
        event.stopPropagation();
        scrolling = false;
        try { edgeScroll.releasePointerCapture(event.pointerId); } catch (_) {}
      }

      edgeScroll.addEventListener("pointerdown", begin);
      edgeScroll.addEventListener("pointermove", move);
      edgeScroll.addEventListener("pointerup", end);
      edgeScroll.addEventListener("pointercancel", end);
    }

    installEdgeScroll();

    function clearLongPress() {
      if (state.longPressTimer) {
        window.clearTimeout(state.longPressTimer);
        state.longPressTimer = 0;
      }
    }

    function touchMidpoint(touches) {
      const first = touches[0];
      const second = touches[1];
      return {
        x: (first.clientX + second.clientX) / 2,
        y: (first.clientY + second.clientY) / 2,
      };
    }

    function endTwoFingerDrag() {
      if (!state.twoFingerDrag) {
        return;
      }
      dispatchMouse("mouseup", 0, 0);
      state.twoFingerDrag = false;
      state.down = false;
      syncUi();
    }

    function setCursor(x, y) {
      state.x = clamp(Math.round(x), 8, window.innerWidth - 8);
      state.y = clamp(Math.round(y), 8, window.innerHeight - 8);
      cursor.style.transform = `translate3d(${state.x}px, ${state.y}px, 0)`;
    }

    toggle.addEventListener("click", () => {
      if (toggleSuppressClick) {
        return;
      }
      state.enabled = !state.enabled;
      if (!state.enabled && (state.drag || state.holdDrag || state.twoFingerDrag)) {
        dispatchMouse("mouseup", 0, 0);
      }
      state.drag = false;
      state.holdDrag = false;
      state.twoFingerDrag = false;
      syncUi();
    });

    root.querySelector(".atm-close").addEventListener("click", () => {
      state.enabled = false;
      if (state.drag || state.twoFingerDrag) {
        dispatchMouse("mouseup", 0, 0);
      }
      state.drag = false;
      state.twoFingerDrag = false;
      syncUi();
    });

    root.querySelector(".atm-reset").addEventListener("click", () => {
      localStorage.removeItem(LAYOUT_KEY);
      applyPanelLayout(defaultPanelLayout());
      savePanelLayout();
      setCursor(window.innerWidth / 2, window.innerHeight / 2);
    });

    root.querySelector(".atm-left").addEventListener("click", leftClick);
    root.querySelector(".atm-right").addEventListener("click", rightClick);
    root.querySelector(".atm-center").addEventListener("click", () => {
      setCursor(window.innerWidth / 2, window.innerHeight / 2);
    });

    dragBtn.addEventListener("click", () => {
      state.drag = !state.drag;
      if (state.drag) {
        dispatchMouse("mousedown", 0, 1);
      } else {
        dispatchMouse("mouseup", 0, 0);
      }
      syncUi();
    });

    scrollBtn.addEventListener("click", () => {
      state.scroll = !state.scroll;
      syncUi();
    });

    pad.addEventListener("pointerdown", (event) => {
      if (!state.enabled || state.twoFingerDrag) {
        return;
      }
      event.preventDefault();
      pad.setPointerCapture(event.pointerId);
      state.down = true;
      state.moved = false;
      syncUi();
      state.lastX = event.clientX;
      state.lastY = event.clientY;
      state.startX = event.clientX;
      state.startY = event.clientY;
      clearLongPress();
      state.longPressTimer = window.setTimeout(() => {
        if (state.down && !state.moved && !state.drag && !state.scroll && !state.holdDrag) {
          state.holdDrag = true;
          state.moved = true;
          syncUi();
          dispatchMouse("mousedown", 0, 1);
        }
      }, 260);
    });

    pad.addEventListener("pointermove", (event) => {
      if (!state.enabled || !state.down || state.twoFingerDrag) {
        return;
      }
      event.preventDefault();
      const dx = event.clientX - state.lastX;
      const dy = event.clientY - state.lastY;
      const total = Math.hypot(event.clientX - state.startX, event.clientY - state.startY);
      if (total > 7) {
        state.moved = true;
        clearLongPress();
      }
      state.lastX = event.clientX;
      state.lastY = event.clientY;

      if (state.scroll) {
        dispatchWheel(-dy * 3.2, -dx * 1.4);
        return;
      }

      const speed = event.shiftKey ? 0.55 : 1.35;
      setCursor(state.x + dx * speed, state.y + dy * speed);
      dispatchMouse("mousemove", 0, (state.drag || state.holdDrag) ? 1 : 0);
    });

    function endPad(event) {
      if (state.twoFingerDrag) {
        event.preventDefault();
        return;
      }
      if (!state.enabled || !state.down) {
        return;
      }
      event.preventDefault();
      clearLongPress();
      state.down = false;
      syncUi();
      try { pad.releasePointerCapture(event.pointerId); } catch (_) {}
      if (state.holdDrag) {
        dispatchMouse("mouseup", 0, 0);
        state.holdDrag = false;
        syncUi();
        return;
      }
      if (!state.moved && !state.drag && !state.scroll) {
        leftClick();
      }
    }

    pad.addEventListener("pointerup", endPad);
    pad.addEventListener("pointercancel", endPad);

    pad.addEventListener("touchstart", (event) => {
      if (!state.enabled || event.touches.length !== 2) {
        return;
      }
      event.preventDefault();
      clearLongPress();
      state.down = false;
      state.moved = true;
      const mid = touchMidpoint(event.touches);
      state.twoFingerLastX = mid.x;
      state.twoFingerLastY = mid.y;
      if (!state.twoFingerDrag) {
        state.twoFingerDrag = true;
        dispatchMouse("mousedown", 0, 1);
        syncUi();
      }
    }, { passive: false });

    pad.addEventListener("touchmove", (event) => {
      if (!state.enabled || !state.twoFingerDrag || event.touches.length !== 2) {
        return;
      }
      event.preventDefault();
      const mid = touchMidpoint(event.touches);
      const dx = mid.x - state.twoFingerLastX;
      const dy = mid.y - state.twoFingerLastY;
      state.twoFingerLastX = mid.x;
      state.twoFingerLastY = mid.y;
      setCursor(state.x + dx * 1.35, state.y + dy * 1.35);
      dispatchMouse("mousemove", 0, 1);
    }, { passive: false });

    pad.addEventListener("touchend", (event) => {
      if (!state.twoFingerDrag) {
        return;
      }
      event.preventDefault();
      if (event.touches.length < 2) {
        endTwoFingerDrag();
      }
    }, { passive: false });

    pad.addEventListener("touchcancel", (event) => {
      if (!state.twoFingerDrag) {
        return;
      }
      event.preventDefault();
      endTwoFingerDrag();
    }, { passive: false });

    window.addEventListener("resize", () => {
      setCursor(state.x, state.y);
    });

    syncUi();
  });
})();
