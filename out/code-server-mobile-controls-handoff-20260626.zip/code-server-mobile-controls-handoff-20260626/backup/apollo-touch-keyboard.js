(() => {
  "use strict";

  if (window.__apolloTouchKeyboardLoaded) {
    return;
  }
  window.__apolloTouchKeyboardLoaded = true;

  const VERSION = "20260626.1";
  const STORE_KEY = "apollo.touchKeyboard.open";
  const LAYOUT_KEY = "apollo.touchKeyboard.panelLayout";
  const TOGGLE_LAYOUT_KEY = "apollo.touchKeyboard.toggleLayout";

  const KEY = {
    Escape: { key: "Escape", code: "Escape", keyCode: 27 },
    Tab: { key: "Tab", code: "Tab", keyCode: 9 },
    Enter: { key: "Enter", code: "Enter", keyCode: 13 },
    Backspace: { key: "Backspace", code: "Backspace", keyCode: 8 },
    Delete: { key: "Delete", code: "Delete", keyCode: 46 },
    Space: { key: " ", code: "Space", keyCode: 32 },
    ArrowUp: { key: "ArrowUp", code: "ArrowUp", keyCode: 38 },
    ArrowDown: { key: "ArrowDown", code: "ArrowDown", keyCode: 40 },
    ArrowLeft: { key: "ArrowLeft", code: "ArrowLeft", keyCode: 37 },
    ArrowRight: { key: "ArrowRight", code: "ArrowRight", keyCode: 39 },
    Home: { key: "Home", code: "Home", keyCode: 36 },
    End: { key: "End", code: "End", keyCode: 35 },
    PageUp: { key: "PageUp", code: "PageUp", keyCode: 33 },
    PageDown: { key: "PageDown", code: "PageDown", keyCode: 34 },
    KeyS: { key: "s", code: "KeyS", keyCode: 83 },
    KeyP: { key: "p", code: "KeyP", keyCode: 80 },
    KeyF: { key: "f", code: "KeyF", keyCode: 70 },
    KeyC: { key: "c", code: "KeyC", keyCode: 67 },
    KeyV: { key: "v", code: "KeyV", keyCode: 86 },
    KeyX: { key: "x", code: "KeyX", keyCode: 88 },
    KeyZ: { key: "z", code: "KeyZ", keyCode: 90 },
    KeyY: { key: "y", code: "KeyY", keyCode: 89 },
    Backquote: { key: "`", code: "Backquote", keyCode: 192 },
  };

  function onReady(fn) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", fn, { once: true });
    } else {
      fn();
    }
  }

  function injectStyle() {
    if (document.getElementById("apollo-touch-keyboard-style")) {
      return;
    }

    const style = document.createElement("style");
    style.id = "apollo-touch-keyboard-style";
    style.textContent = `
      #apollo-touch-keyboard-root {
        position: fixed;
        inset: 0;
        z-index: 2147483645;
        pointer-events: none;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      }

      #apollo-touch-keyboard-root .akb-toggle {
        position: fixed;
        left: max(12px, env(safe-area-inset-left));
        bottom: max(12px, env(safe-area-inset-bottom));
        min-width: 58px;
        height: 42px;
        border: 1px solid rgba(255, 255, 255, 0.24);
        border-radius: 999px;
        background: rgba(31, 41, 55, 0.88);
        color: #ffffff;
        box-shadow: 0 10px 28px rgba(0, 0, 0, 0.38);
        backdrop-filter: blur(14px);
        pointer-events: auto;
        touch-action: none;
        cursor: grab;
        font-size: 13px;
        font-weight: 650;
      }

      #apollo-touch-keyboard-root.akb-open .akb-toggle {
        background: rgba(5, 150, 105, 0.94);
      }

      #apollo-touch-keyboard-root .akb-panel {
        position: fixed;
        left: 50%;
        bottom: max(62px, calc(env(safe-area-inset-bottom) + 62px));
        transform: translateX(-50%);
        width: min(96vw, 780px);
        border: 1px solid rgba(255, 255, 255, 0.18);
        border-radius: 16px;
        background: rgba(15, 23, 42, 0.92);
        color: #ffffff;
        box-shadow: 0 22px 56px rgba(0, 0, 0, 0.52);
        backdrop-filter: blur(16px);
        pointer-events: auto;
        touch-action: manipulation;
        display: none;
        user-select: none;
        -webkit-user-select: none;
        overflow: auto;
        min-width: 320px;
        min-height: 180px;
        max-width: calc(100vw - 12px);
        max-height: calc(100vh - 12px);
      }

      #apollo-touch-keyboard-root.akb-open .akb-panel {
        display: block;
      }

      #apollo-touch-keyboard-root .akb-header,
      #apollo-touch-keyboard-root .akb-row {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 7px 9px;
      }

      #apollo-touch-keyboard-root .akb-header {
        border-bottom: 1px solid rgba(255, 255, 255, 0.10);
        cursor: move;
        touch-action: none;
      }

      #apollo-touch-keyboard-root .akb-resize {
        position: absolute;
        right: 5px;
        bottom: 5px;
        width: 22px;
        height: 22px;
        border-radius: 7px;
        background: linear-gradient(135deg, transparent 0 45%, rgba(255,255,255,0.35) 46% 54%, transparent 55%), linear-gradient(135deg, transparent 0 63%, rgba(255,255,255,0.28) 64% 72%, transparent 73%);
        cursor: nwse-resize;
        touch-action: none;
        pointer-events: auto;
        opacity: 0.85;
      }

      #apollo-touch-keyboard-root .akb-title {
        flex: 1;
        font-size: 13px;
        font-weight: 650;
      }

      #apollo-touch-keyboard-root .akb-status {
        font-size: 11px;
        color: rgba(255, 255, 255, 0.66);
      }

      #apollo-touch-keyboard-root .akb-row {
        border-bottom: 1px solid rgba(255, 255, 255, 0.075);
        overflow-x: auto;
        scrollbar-width: none;
        padding-right: 42px;
      }

      #apollo-touch-keyboard-root .akb-row:last-child {
        border-bottom: 0;
      }

      #apollo-touch-keyboard-root .akb-row::-webkit-scrollbar {
        display: none;
      }

      #apollo-touch-keyboard-root .akb-key {
        flex: 0 0 auto;
        height: 38px;
        min-width: 42px;
        padding: 0 10px;
        border: 1px solid rgba(255, 255, 255, 0.16);
        border-radius: 9px;
        background: rgba(255, 255, 255, 0.105);
        color: #ffffff;
        font-size: 12px;
        font-weight: 650;
        pointer-events: auto;
        touch-action: manipulation;
      }

      #apollo-touch-keyboard-root .akb-key.akb-wide {
        min-width: 74px;
      }

      #apollo-touch-keyboard-root .akb-key.akb-xwide {
        min-width: 116px;
      }

      #apollo-touch-keyboard-root .akb-key:active,
      #apollo-touch-keyboard-root .akb-key.akb-active {
        background: rgba(5, 150, 105, 0.95);
        border-color: rgba(167, 243, 208, 0.78);
      }

      #apollo-touch-keyboard-root .akb-move {
        min-width: 58px;
        background: rgba(245, 158, 11, 0.96);
        border-color: rgba(253, 230, 138, 0.92);
        color: #111827;
      }

      #apollo-touch-keyboard-root .akb-key.akb-danger {
        background: rgba(127, 29, 29, 0.66);
      }

      #apollo-touch-keyboard-root .akb-key.akb-primary {
        background: rgba(37, 99, 235, 0.76);
      }

      #apollo-touch-keyboard-root .akb-edge-scroll {
        position: absolute;
        top: 50px;
        right: 5px;
        bottom: 10px;
        width: 28px;
        border: 1px solid rgba(167, 243, 208, 0.42);
        border-radius: 999px;
        background: rgba(5, 150, 105, 0.42);
        color: rgba(255, 255, 255, 0.88);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        font-weight: 750;
        pointer-events: auto;
        touch-action: none;
        user-select: none;
        -webkit-user-select: none;
        z-index: 3;
      }

      #apollo-touch-keyboard-root .akb-edge-scroll span {
        transform: rotate(90deg);
        white-space: nowrap;
      }

      #apollo-touch-keyboard-root .akb-edge-scroll:active {
        background: rgba(5, 150, 105, 0.78);
        border-color: rgba(209, 250, 229, 0.84);
      }

      #apollo-touch-keyboard-root .akb-spacer {
        flex: 1 0 10px;
      }

      @media (max-width: 760px) {
        #apollo-touch-keyboard-root .akb-status { display: none; }
        #apollo-touch-keyboard-root .akb-panel {
          width: calc(100vw - 12px);
          bottom: max(56px, calc(env(safe-area-inset-bottom) + 56px));
          border-radius: 13px;
        }
        #apollo-touch-keyboard-root .akb-row {
          padding: 6px 7px;
          gap: 5px;
        }
        #apollo-touch-keyboard-root .akb-key {
          height: 36px;
          min-width: 40px;
          padding: 0 9px;
        }
      }
    `;
    document.head.appendChild(style);
  }

  function createRoot() {
    const root = document.createElement("div");
    root.id = "apollo-touch-keyboard-root";
    root.dataset.version = VERSION;
    root.innerHTML = `
      <button class="akb-toggle" type="button" aria-label="Toggle laptop keys">Keys</button>
      <section class="akb-panel" aria-label="Laptop key panel">
        <div class="akb-header">
          <div class="akb-title">Laptop Keys</div>
          <div class="akb-status">Ctrl/Shift/Alt sticky untuk shortcut berikutnya</div>
          <button class="akb-key akb-move" type="button">Move</button>
          <button class="akb-key akb-reset" type="button">Reset</button>
          <button class="akb-key akb-hide" type="button">Hide</button>
        </div>
        <div class="akb-row">
          <button class="akb-key" data-key="Escape">Esc</button>
          <button class="akb-key" data-key="Tab">Tab</button>
          <button class="akb-key akb-mod" data-mod="ctrl">Ctrl</button>
          <button class="akb-key akb-mod" data-mod="shift">Shift</button>
          <button class="akb-key akb-mod" data-mod="alt">Alt</button>
          <button class="akb-key akb-mod" data-mod="meta">Cmd</button>
          <span class="akb-spacer"></span>
          <button class="akb-key akb-wide akb-primary" data-native="1">ABC</button>
        </div>
        <div class="akb-row">
          <button class="akb-key akb-wide" data-combo="save">Save</button>
          <button class="akb-key akb-wide" data-combo="palette">Cmd Pal</button>
          <button class="akb-key akb-wide" data-combo="quickopen">Quick</button>
          <button class="akb-key akb-wide" data-combo="find">Find</button>
          <button class="akb-key akb-wide" data-combo="terminal">Terminal</button>
          <button class="akb-key akb-wide" data-combo="comment">Comment</button>
        </div>
        <div class="akb-row">
          <button class="akb-key" data-key="Home">Home</button>
          <button class="akb-key" data-key="End">End</button>
          <button class="akb-key" data-key="PageUp">PgUp</button>
          <button class="akb-key" data-key="ArrowUp">Up</button>
          <button class="akb-key" data-key="PageDown">PgDn</button>
          <button class="akb-key" data-key="ArrowLeft">Left</button>
          <button class="akb-key" data-key="ArrowDown">Down</button>
          <button class="akb-key" data-key="ArrowRight">Right</button>
        </div>
        <div class="akb-row">
          <button class="akb-key akb-wide" data-combo="undo">Undo</button>
          <button class="akb-key akb-wide" data-combo="redo">Redo</button>
          <button class="akb-key akb-wide" data-combo="copy">Copy</button>
          <button class="akb-key akb-wide" data-combo="cut">Cut</button>
          <button class="akb-key akb-wide" data-combo="paste">Paste</button>
          <button class="akb-key" data-key="Delete">Del</button>
          <button class="akb-key akb-wide" data-key="Backspace">Backsp</button>
          <button class="akb-key akb-wide" data-key="Enter">Enter</button>
        </div>
        <div class="akb-row">
          <button class="akb-key akb-xwide" data-key="Space">Space</button>
          <button class="akb-key akb-wide" data-combo="ctrlslash">Ctrl+/</button>
          <button class="akb-key akb-wide" data-combo="ctrlshiftf">Search</button>
          <button class="akb-key akb-wide" data-combo="explorer">Files</button>
          <span class="akb-spacer"></span>
          <button class="akb-key akb-danger akb-clear-mods">Clear</button>
        </div>
        <div class="akb-edge-scroll" role="slider" aria-label="Edge scroll"><span>Scroll</span></div>
        <div class="akb-resize" aria-label="Resize laptop key panel"></div>
      </section>
    `;
    document.body.appendChild(root);
    return root;
  }

  onReady(() => {
    injectStyle();

    const existing = document.getElementById("apollo-touch-keyboard-root");
    if (existing) {
      existing.remove();
    }

    const root = createRoot();
    const toggle = root.querySelector(".akb-toggle");
    const panel = root.querySelector(".akb-panel");
    const header = root.querySelector(".akb-header");
    const resizeHandle = root.querySelector(".akb-resize");
    const moveHandle = root.querySelector(".akb-move");
    const edgeScroll = root.querySelector(".akb-edge-scroll");
    const mods = { ctrl: false, shift: false, alt: false, meta: false };
    let toggleSuppressClick = false;
    let open = localStorage.getItem(STORE_KEY) === "1";
    let lastWorkTarget = null;



    function limit(value, min, max) {
      return Math.max(min, Math.min(max, value));
    }

    function defaultPanelLayout() {
      const width = Math.round(Math.min(window.innerWidth * 0.96, 780));
      const height = Math.round(Math.max(230, Math.min(window.innerHeight * 0.42, 330)));
      return {
        left: Math.round((window.innerWidth - width) / 2),
        top: Math.round(window.innerHeight - height - 62),
        width,
        height,
      };
    }

    function clampPanelLayout(layout) {
      const margin = 6;
      const minWidth = Math.min(320, Math.max(180, window.innerWidth - margin * 2));
      const minHeight = Math.min(180, Math.max(140, window.innerHeight - margin * 2));
      const maxWidth = Math.max(minWidth, window.innerWidth - margin * 2);
      const maxHeight = Math.max(minHeight, window.innerHeight - margin * 2);
      const width = limit(Number(layout.width) || minWidth, minWidth, maxWidth);
      const height = limit(Number(layout.height) || minHeight, minHeight, maxHeight);
      return {
        left: limit(Number(layout.left) || margin, margin, window.innerWidth - width - margin),
        top: limit(Number(layout.top) || margin, margin, window.innerHeight - height - margin),
        width,
        height,
      };
    }

    function applyPanelLayout(layout) {
      const safe = clampPanelLayout(layout);
      panel.style.left = `${safe.left}px`;
      panel.style.top = `${safe.top}px`;
      panel.style.width = `${safe.width}px`;
      panel.style.height = `${safe.height}px`;
      panel.style.right = "auto";
      panel.style.bottom = "auto";
      panel.style.transform = "none";
      return safe;
    }

    function readPanelLayout() {
      return {
        left: parseFloat(panel.style.left) || panel.getBoundingClientRect().left,
        top: parseFloat(panel.style.top) || panel.getBoundingClientRect().top,
        width: parseFloat(panel.style.width) || panel.getBoundingClientRect().width,
        height: parseFloat(panel.style.height) || panel.getBoundingClientRect().height,
      };
    }

    function savePanelLayout() {
      localStorage.setItem(LAYOUT_KEY, JSON.stringify(clampPanelLayout(readPanelLayout())));
    }

    function loadPanelLayout() {
      let layout = null;
      try { layout = JSON.parse(localStorage.getItem(LAYOUT_KEY) || "null"); } catch (_) {}
      applyPanelLayout(layout || defaultPanelLayout());
    }

    function installPanelMoveResize() {
      let mode = null;
      let startX = 0;
      let startY = 0;
      let startLayout = null;

      function begin(event, nextMode) {
        event.preventDefault();
        event.stopPropagation();
        mode = nextMode;
        try { event.currentTarget.setPointerCapture(event.pointerId); } catch (_) {}
        startX = event.clientX;
        startY = event.clientY;
        startLayout = readPanelLayout();
      }

      function move(event) {
        if (!mode || !startLayout) {
          return;
        }
        event.preventDefault();
        const dx = event.clientX - startX;
        const dy = event.clientY - startY;
        if (mode === "move") {
          applyPanelLayout({ ...startLayout, left: startLayout.left + dx, top: startLayout.top + dy });
        } else if (mode === "resize") {
          applyPanelLayout({ ...startLayout, width: startLayout.width + dx, height: startLayout.height + dy });
        }
      }

      function end() {
        if (!mode) {
          return;
        }
        savePanelLayout();
        mode = null;
        startLayout = null;
      }

      header.addEventListener("pointerdown", (event) => {
        if (event.target.closest("button")) {
          return;
        }
        begin(event, "move");
      });
      moveHandle.addEventListener("pointerdown", (event) => begin(event, "move"));
      resizeHandle.addEventListener("pointerdown", (event) => begin(event, "resize"));
      window.addEventListener("pointermove", move);
      window.addEventListener("pointerup", end);
      window.addEventListener("pointercancel", end);
      window.addEventListener("resize", () => {
        applyPanelLayout(readPanelLayout());
        savePanelLayout();
      });
    }

    loadPanelLayout();
    installPanelMoveResize();



    function defaultToggleLayout() {
      const rectWidth = 68;
      const rectHeight = 42;
      const margin = 12;
      return {
        left: margin,
        top: Math.round(window.innerHeight - rectHeight - margin),
        width: rectWidth,
        height: rectHeight,
      };
    }

    function clampToggleLayout(layout) {
      const margin = 6;
      const rect = toggle.getBoundingClientRect();
      const width = Number(layout.width) || rect.width || 68;
      const height = Number(layout.height) || rect.height || 42;
      return {
        left: limit(Number(layout.left) || margin, margin, window.innerWidth - width - margin),
        top: limit(Number(layout.top) || margin, margin, window.innerHeight - height - margin),
        width,
        height,
      };
    }

    function applyToggleLayout(layout) {
      const safe = clampToggleLayout(layout);
      toggle.style.left = `${safe.left}px`;
      toggle.style.top = `${safe.top}px`;
      toggle.style.right = "auto";
      toggle.style.bottom = "auto";
      return safe;
    }

    function readToggleLayout() {
      const rect = toggle.getBoundingClientRect();
      return {
        left: parseFloat(toggle.style.left) || rect.left,
        top: parseFloat(toggle.style.top) || rect.top,
        width: rect.width,
        height: rect.height,
      };
    }

    function saveToggleLayout() {
      localStorage.setItem(TOGGLE_LAYOUT_KEY, JSON.stringify(clampToggleLayout(readToggleLayout())));
    }

    function loadToggleLayout() {
      let layout = null;
      try { layout = JSON.parse(localStorage.getItem(TOGGLE_LAYOUT_KEY) || "null"); } catch (_) {}
      applyToggleLayout(layout || defaultToggleLayout());
    }

    function installToggleMove() {
      let moving = false;
      let moved = false;
      let startX = 0;
      let startY = 0;
      let startLayout = null;

      toggle.addEventListener("pointerdown", (event) => {
        if (event.button && event.button !== 0) {
          return;
        }
        moving = true;
        moved = false;
        startX = event.clientX;
        startY = event.clientY;
        startLayout = readToggleLayout();
        try { toggle.setPointerCapture(event.pointerId); } catch (_) {}
      });

      toggle.addEventListener("pointermove", (event) => {
        if (!moving || !startLayout) {
          return;
        }
        const dx = event.clientX - startX;
        const dy = event.clientY - startY;
        if (Math.hypot(dx, dy) > 5) {
          moved = true;
          toggleSuppressClick = true;
        }
        if (moved) {
          event.preventDefault();
          applyToggleLayout({ ...startLayout, left: startLayout.left + dx, top: startLayout.top + dy });
        }
      });

      function endMove(event) {
        if (!moving) {
          return;
        }
        if (moved) {
          event.preventDefault();
          saveToggleLayout();
          window.setTimeout(() => { toggleSuppressClick = false; }, 80);
        }
        moving = false;
        moved = false;
        startLayout = null;
      }

      toggle.addEventListener("pointerup", endMove);
      toggle.addEventListener("pointercancel", endMove);
      window.addEventListener("resize", () => {
        applyToggleLayout(readToggleLayout());
        saveToggleLayout();
      });
    }

    loadToggleLayout();
    installToggleMove();

    function syncUi() {
      root.classList.toggle("akb-open", open);
      toggle.textContent = open ? "Keys On" : "Keys";
      for (const [name, active] of Object.entries(mods)) {
        const btn = root.querySelector(`[data-mod="${name}"]`);
        if (btn) {
          btn.classList.toggle("akb-active", active);
        }
      }
      localStorage.setItem(STORE_KEY, open ? "1" : "0");
    }

    function rememberWorkTarget() {
      const active = document.activeElement;
      if (active && active !== document.body && active !== document.documentElement && !root.contains(active)) {
        lastWorkTarget = active;
      }
    }

    function hideNativeKeyboard() {
      try {
        if (navigator.virtualKeyboard && typeof navigator.virtualKeyboard.hide === "function") {
          navigator.virtualKeyboard.hide();
        }
      } catch (_) {}
      const active = document.activeElement;
      if (active && !root.contains(active) && (active.matches?.("textarea, input") || active.isContentEditable)) {
        try { active.blur(); } catch (_) {}
      }
    }

    document.addEventListener("pointerdown", (event) => {
      if (!root.contains(event.target)) {
        rememberWorkTarget();
      }
    }, true);

    function findTarget() {
      const active = document.activeElement;
      if (active && active !== document.body && active !== document.documentElement && !root.contains(active)) {
        lastWorkTarget = active;
        return active;
      }
      if (lastWorkTarget && document.contains(lastWorkTarget) && !root.contains(lastWorkTarget)) {
        return lastWorkTarget;
      }

      const selectors = [
        ".monaco-editor.focused textarea.inputarea",
        ".monaco-editor textarea.inputarea",
        ".xterm-helper-textarea",
        "textarea:not([readonly])",
        "input:not([readonly])",
      ];
      for (const selector of selectors) {
        const el = document.querySelector(selector);
        if (el) {
          return el;
        }
      }
      return document.body;
    }

    function focusTarget(target) {
      if (target && typeof target.focus === "function") {
        try {
          target.focus({ preventScroll: true });
        } catch (_) {
          try { target.focus(); } catch (_) {}
        }
      }
    }

    function targetForScroll() {
      const active = findTarget();
      if (active && active.closest) {
        const scrollHost = active.closest(".monaco-editor, .monaco-scrollable-element, .xterm, .terminal, .terminal-wrapper, textarea, input, [contenteditable=true]");
        if (scrollHost && !root.contains(scrollHost)) {
          return scrollHost;
        }
      }
      const oldVisibility = root.style.visibility;
      root.style.visibility = "hidden";
      const target = document.elementFromPoint(window.innerWidth / 2, window.innerHeight / 2) || document.body;
      root.style.visibility = oldVisibility;
      return target;
    }

    function dispatchWheel(deltaY, deltaX = 0) {
      const target = targetForScroll();
      const rect = target.getBoundingClientRect ? target.getBoundingClientRect() : null;
      const clientX = rect && rect.width ? rect.left + rect.width / 2 : window.innerWidth / 2;
      const clientY = rect && rect.height ? rect.top + Math.min(rect.height / 2, 80) : window.innerHeight / 2;
      target.dispatchEvent(new WheelEvent("wheel", {
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window,
        clientX,
        clientY,
        deltaX,
        deltaY,
        deltaMode: WheelEvent.DOM_DELTA_PIXEL,
      }));
    }

    function installEdgeScroll() {
      let scrolling = false;
      let lastX = 0;
      let lastY = 0;

      function begin(event) {
        if (!open || (event.button && event.button !== 0)) {
          return;
        }
        event.preventDefault();
        event.stopPropagation();
        rememberWorkTarget();
        hideNativeKeyboard();
        scrolling = true;
        lastX = event.clientX;
        lastY = event.clientY;
        try { edgeScroll.setPointerCapture(event.pointerId); } catch (_) {}
      }

      function move(event) {
        if (!scrolling) {
          return;
        }
        event.preventDefault();
        event.stopPropagation();
        const dx = event.clientX - lastX;
        const dy = event.clientY - lastY;
        lastX = event.clientX;
        lastY = event.clientY;
        dispatchWheel(-dy * 4.4, -dx * 1.5);
      }

      function end(event) {
        if (!scrolling) {
          return;
        }
        event.preventDefault();
        event.stopPropagation();
        scrolling = false;
        try { edgeScroll.releasePointerCapture(event.pointerId); } catch (_) {}
      }

      edgeScroll.addEventListener("pointerdown", begin);
      edgeScroll.addEventListener("pointermove", move);
      edgeScroll.addEventListener("pointerup", end);
      edgeScroll.addEventListener("pointercancel", end);
    }

    installEdgeScroll();

    function makeKeyboardEvent(type, spec, extraMods) {
      const init = {
        key: spec.key,
        code: spec.code,
        location: 0,
        bubbles: true,
        cancelable: true,
        composed: true,
        ctrlKey: !!extraMods.ctrl,
        shiftKey: !!extraMods.shift,
        altKey: !!extraMods.alt,
        metaKey: !!extraMods.meta,
      };
      const event = new KeyboardEvent(type, init);
      try { Object.defineProperty(event, "keyCode", { get: () => spec.keyCode }); } catch (_) {}
      try { Object.defineProperty(event, "which", { get: () => spec.keyCode }); } catch (_) {}
      return event;
    }

    function pressKey(spec, extraMods = {}) {
      rememberWorkTarget();
      const target = findTarget();
      const mergedMods = {
        ctrl: mods.ctrl || !!extraMods.ctrl,
        shift: mods.shift || !!extraMods.shift,
        alt: mods.alt || !!extraMods.alt,
        meta: mods.meta || !!extraMods.meta,
      };
      target.dispatchEvent(makeKeyboardEvent("keydown", spec, mergedMods));
      target.dispatchEvent(makeKeyboardEvent("keyup", spec, mergedMods));
      hideNativeKeyboard();
      for (const key of Object.keys(mods)) {
        mods[key] = false;
      }
      syncUi();
    }

    function isTerminalTarget(target) {
      if (!target || !target.closest) {
        return false;
      }
      return !!target.closest(".terminal, .terminal-wrapper, .terminal-instance, .xterm, .xterm-screen, .xterm-helper-textarea");
    }

    function combo(name) {
      const slash = { key: "/", code: "Slash", keyCode: 191 };
      const map = {
        save: [KEY.KeyS, { ctrl: true }],
        palette: [KEY.KeyP, { ctrl: true, shift: true }],
        quickopen: [KEY.KeyP, { ctrl: true }],
        find: [KEY.KeyF, { ctrl: true }],
        terminal: [KEY.Backquote, { ctrl: true, shift: true }],
        comment: [slash, { ctrl: true }],
        undo: [KEY.KeyZ, { ctrl: true }],
        redo: [KEY.KeyY, { ctrl: true }],
        copy: [KEY.KeyC, { ctrl: true }],
        cut: [KEY.KeyX, { ctrl: true }],
        paste: [KEY.KeyV, { ctrl: true }],
        ctrlslash: [slash, { ctrl: true }],
        ctrlshiftf: [KEY.KeyF, { ctrl: true, shift: true }],
        explorer: [{ key: "e", code: "KeyE", keyCode: 69 }, { ctrl: true, shift: true }],
      };
      if (name === "copy") {
        const target = findTarget();
        pressKey(KEY.KeyC, isTerminalTarget(target) ? { ctrl: true, shift: true } : { ctrl: true });
        return;
      }
      const item = map[name];
      if (item) {
        pressKey(item[0], item[1]);
      }
    }

    function openNativeKeyboard() {
      const target = findTarget();
      focusTarget(target);

      if (target === document.body || target === document.documentElement) {
        const editorArea = document.querySelector(".monaco-editor textarea.inputarea, .xterm-helper-textarea, textarea:not([readonly]), input:not([readonly])");
        if (editorArea) {
          focusTarget(editorArea);
          return;
        }
      }

      try {
        const clickTarget = target.closest && target.closest(".monaco-editor, .terminal, textarea, input");
        if (clickTarget) {
          const rect = clickTarget.getBoundingClientRect();
          clickTarget.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, clientX: rect.left + 24, clientY: rect.top + 24 }));
          clickTarget.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, clientX: rect.left + 24, clientY: rect.top + 24 }));
          clickTarget.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, clientX: rect.left + 24, clientY: rect.top + 24 }));
        }
      } catch (_) {}
      focusTarget(findTarget());
    }

    toggle.addEventListener("click", () => {
      if (toggleSuppressClick) {
        return;
      }
      open = !open;
      syncUi();
    });

    root.querySelector(".akb-hide").addEventListener("click", () => {
      open = false;
      syncUi();
    });

    root.querySelector(".akb-reset").addEventListener("click", () => {
      localStorage.removeItem(LAYOUT_KEY);
      applyPanelLayout(defaultPanelLayout());
      savePanelLayout();
      hideNativeKeyboard();
    });

    root.querySelector(".akb-clear-mods").addEventListener("click", () => {
      for (const key of Object.keys(mods)) {
        mods[key] = false;
      }
      syncUi();
    });

    root.addEventListener("pointerdown", (event) => {
      const button = event.target.closest("button");
      if (!button || button.dataset.native === "1" || button.classList.contains("akb-toggle")) {
        return;
      }
      rememberWorkTarget();
      hideNativeKeyboard();
    }, true);

    root.addEventListener("click", (event) => {
      const button = event.target.closest("button");
      if (!button || button.classList.contains("akb-toggle") || button.classList.contains("akb-hide") || button.classList.contains("akb-move") || button.classList.contains("akb-reset") || button.classList.contains("akb-clear-mods")) {
        return;
      }
      event.preventDefault();
      const mod = button.dataset.mod;
      const key = button.dataset.key;
      const comboName = button.dataset.combo;
      const native = button.dataset.native;

      if (mod) {
        mods[mod] = !mods[mod];
        syncUi();
        return;
      }
      if (native) {
        openNativeKeyboard();
        return;
      }
      if (comboName) {
        combo(comboName);
        return;
      }
      if (key && KEY[key]) {
        pressKey(KEY[key]);
      }
    });

    syncUi();
  });
})();
